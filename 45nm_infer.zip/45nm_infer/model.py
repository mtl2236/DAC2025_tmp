import torch
from torch_geometric.nn import GCNConv, GATConv
from torch_geometric.nn.norm import BatchNorm
import torch.nn.functional as F
from torch_geometric.nn.norm import LayerNorm
from torch_geometric.nn import global_mean_pool
from torch.nn import Sequential as Seq, Linear as Lin, ReLU, LayerNorm
from torch_geometric.nn import GAE
from sklearn.metrics import roc_auc_score, average_precision_score
from torch_geometric.utils import negative_sampling
import numpy as np

""" workload embedding """ 
class Encoder(torch.nn.Module):
    def __init__(self, in_channels, gnn_hidden_channels_list, out_channels):
        super(Encoder, self).__init__()
        
        ''' Number of GNN layers and MLP layers '''
        self.num_gnn_layers = len(gnn_hidden_channels_list)

        ''' GCN layers as encoder '''
        self.convs = torch.nn.ModuleList()
        self.convs.append(GCNConv(in_channels, gnn_hidden_channels_list[0]))
        for i in range(self.num_gnn_layers - 1):
            self.convs.append(GCNConv(gnn_hidden_channels_list[i], gnn_hidden_channels_list[i + 1]))
        self.convs.append(GCNConv(gnn_hidden_channels_list[-1], out_channels))
        
        ''' Layer normalization for encoder '''
        self.norms = torch.nn.ModuleList()
        for i in range(self.num_gnn_layers):
            self.norms.append(LayerNorm(gnn_hidden_channels_list[i]))

    def forward(self, data):
        
        # x = data.x
        x = torch.cat((data.x, data.work_seq[:, 0].unsqueeze(-1)), dim = 1)
        edge_index = data.edge_index
        
        ''' Encoder '''
        for i in range(self.num_gnn_layers):
            x = self.convs[i](x, edge_index)
            x = F.relu(x)
            x = self.norms[i](x)
        node_embedding = self.convs[-1](x, edge_index)
        graph_embedding = global_mean_pool(node_embedding, data.batch)
        
        return node_embedding, graph_embedding

class WorkloadDecoder(torch.nn.Module):
    def __init__(self, in_channels, mlp_hidden_channels_list, out_channels):
        super(WorkloadDecoder, self).__init__()
        
        ''' Number of MLP layers '''
        self.num_mlp_layers = len(mlp_hidden_channels_list)

        ''' MLP layers as workload decoder '''
        self.mlp = torch.nn.ModuleList()
        self.mlp_norms = torch.nn.ModuleList()
        if self.num_mlp_layers == 0:
            self.mlp.append(Lin(in_channels, out_channels))
        else:
            self.mlp.append(Seq(Lin(in_channels, mlp_hidden_channels_list[0]), ReLU()))
            self.mlp_norms.append(LayerNorm(mlp_hidden_channels_list[0]))
            
            for i in range(self.num_mlp_layers - 1):
                self.mlp.append(Seq(Lin(mlp_hidden_channels_list[i], mlp_hidden_channels_list[i + 1]), ReLU()))
                self.mlp_norms.append(LayerNorm(mlp_hidden_channels_list[i+1]))
            
            self.mlp.append(Lin(mlp_hidden_channels_list[-1], out_channels))

    def forward(self, x):
        ''' Workload decoder '''
        for i in range(self.num_mlp_layers):
            x = self.mlp[i](x)
            x = self.mlp_norms[i](x)
        workload_recon = torch.sigmoid(self.mlp[-1](x))   
        return workload_recon

class PinDecoder(torch.nn.Module):
    def __init__(self, in_channels, mlp_hidden_channels_list, out_channels):
        super(PinDecoder, self).__init__()
        
        ''' Number of MLP layers '''
        self.num_mlp_layers = len(mlp_hidden_channels_list)

        ''' MLP layers as workload decoder '''
        self.mlp = torch.nn.ModuleList()
        self.mlp_norms = torch.nn.ModuleList()
        if self.num_mlp_layers == 0:
            self.mlp.append(Lin(in_channels, out_channels))
        else:
            self.mlp.append(Seq(Lin(in_channels, mlp_hidden_channels_list[0]), ReLU()))
            self.mlp_norms.append(LayerNorm(mlp_hidden_channels_list[0]))
            
            for i in range(self.num_mlp_layers - 1):
                self.mlp.append(Seq(Lin(mlp_hidden_channels_list[i], mlp_hidden_channels_list[i + 1]), ReLU()))
                self.mlp_norms.append(LayerNorm(mlp_hidden_channels_list[i+1]))
            
            self.mlp.append(Lin(mlp_hidden_channels_list[-1], out_channels))
            
    def forward(self, x):
        ''' Pin decoder '''
        for i in range(self.num_mlp_layers):
            x = self.mlp[i](x)
            x = self.mlp_norms[i](x)
        return self.mlp[-1](x)
    
class Baseline_GAE(GAE):
    def __init__(self, encoder, decoder, workload_decoder, pin_decoder):
        super(Baseline_GAE, self).__init__(encoder, decoder)
        self.workload_decoder = workload_decoder
        self.pin_decoder = pin_decoder
        
    def forward(self, data):
        
        ''' embedding computation '''
        # node and graph embedding by encoder
        z, g = self.encoder(data)
        
        # workload reconstruction by workload decoder
        recons_w = self.attr_decoder(z)
        
        # pin classification by pin decoder
        pin_pred = self.pin_decoder(z)
        
        ''' loss computation '''
        # Compute loss: Reconstruct adjacency matrix
        loss_s = self.recon_loss(z, data.edge_index, data.batch, data.neg_edge_index)
        
        # Compute loss: Reconstruct workload
        mask = data.in_mask.bool()
        # print(recons_w[mask], data.x[:, -1].unsqueeze(1)[mask])
        loss_w = F.binary_cross_entropy(recons_w[mask], data.x[:, -1].unsqueeze(1)[mask])
        recon_loss = F.l1_loss(recons_w[mask], data.x[:, -1].unsqueeze(1)[mask]) # another metric but not used for training
        
        # Compute loss: Pin classification
        loss_p = F.cross_entropy(pin_pred, data.y_state.squeeze())
        
        return z, g, loss_s.unsqueeze(0), loss_w.unsqueeze(0), loss_p.unsqueeze(0), recon_loss.unsqueeze(0), pin_pred
        
    def attr_decoder(self, x):
        return self.workload_decoder(x)
          
    def recon_loss(self, z, pos_edge_index, batch,
                neg_edge_index = None):
        r"""Given latent variables :obj:`z`, computes the binary cross
        entropy loss for positive edges :obj:`pos_edge_index` and negative
        sampled edges, separately for each graph in the batch.

        Args:
            z (torch.Tensor): The latent space :math:`\mathbf{Z}`.
            pos_edge_index (torch.Tensor): The positive edges to train against.
            neg_edge_index (torch.Tensor, optional): The negative edges to
                train against. If not given, uses negative sampling to
                calculate negative edges. (default: :obj:`None`)
            batch (torch.Tensor): A tensor indicating the graph index for each node in the batch.
        """
        # EPS = 1e-15
        pos_loss = -torch.log(
            self.decoder(z, pos_edge_index, sigmoid=True) + 1e-15)

        if neg_edge_index is None:
            # neg_edge_index = batched_negative_sampling(pos_edge_index, batch)
            # neg_edge_index = negative_sampling(pos_edge_index, z.size(0))
            print("neg_edge_index is None, bye")
        neg_loss = -torch.log(1 -
                              self.decoder(z, neg_edge_index, sigmoid=True) +
                              1e-15)
        
        # Assign each edge to the corresponding graph using the `batch` tensor.
        # `batch` is used to map nodes to graphs; we need to map edges to the corresponding graph.
        pos_graph_batch = batch[pos_edge_index[0]]  # Get the batch index for positive edges.
        neg_graph_batch = batch[neg_edge_index[0]]  # Get the batch index for negative edges.
        
        # Use global mean pooling to average losses across all graphs.
        pos_loss_per_graph = global_mean_pool(pos_loss, pos_graph_batch).mean()
        neg_loss_per_graph = global_mean_pool(neg_loss, neg_graph_batch).mean()
        
        # print(pos_loss_per_graph, neg_loss_per_graph)
        return pos_loss_per_graph + neg_loss_per_graph
 
''' Baseline model for graph regression '''
class GAT_base(torch.nn.Module):
    def __init__(self, in_channels, gnn_hidden_channels_list, mlp_hidden_channels_list, mlp_hidden_pin, out_channels, out_pins, head):
        super(GAT_base, self).__init__()
        
        ''' Number of GNN layers and MLP layers '''
        self.num_gnn_layers = len(gnn_hidden_channels_list)
        self.num_mlp_layers = len(mlp_hidden_channels_list)
        self.num_mlp_pin = len(mlp_hidden_pin)
        self.head = head

        ''' GCN layers as feature extractor '''
        self.convs = torch.nn.ModuleList()
        self.convs.append(GATConv(in_channels, gnn_hidden_channels_list[0], self.head, concat=True, edge_dim = 5))

        for i in range(self.num_gnn_layers - 1):
            if i == self.num_gnn_layers - 2:
                self.convs.append(GATConv(self.head * gnn_hidden_channels_list[i], gnn_hidden_channels_list[i + 1], self.head, concat = False ,edge_dim = 5))
            else:
                self.convs.append(GATConv(self.head * gnn_hidden_channels_list[i], gnn_hidden_channels_list[i + 1], self.head, concat = True ,edge_dim = 5))
                
        ''' Layer normalization for GNN layers '''
        self.norms = torch.nn.ModuleList()
        for i in range(self.num_gnn_layers):
            if i == self.num_gnn_layers - 1:
                self.norms.append(LayerNorm(gnn_hidden_channels_list[i]))
            else:
                self.norms.append(LayerNorm(self.head * gnn_hidden_channels_list[i]))


        ''' MLP layers as classifier '''
        self.mlp = torch.nn.ModuleList()
        self.mlp_norms = torch.nn.ModuleList()
        if self.num_mlp_layers == 0:
            self.mlp.append(Lin(gnn_hidden_channels_list[-1] + 32, out_channels))
        else:
            self.mlp.append(Seq(Lin(gnn_hidden_channels_list[-1] + 32, mlp_hidden_channels_list[0]), ReLU()))
            self.mlp_norms.append(LayerNorm(mlp_hidden_channels_list[0]))
            
            for i in range(self.num_mlp_layers - 1):
                self.mlp.append(Seq(Lin(mlp_hidden_channels_list[i], mlp_hidden_channels_list[i + 1]), ReLU()))
                self.mlp_norms.append(LayerNorm(mlp_hidden_channels_list[i+1]))
            
            self.mlp.append(Lin(mlp_hidden_channels_list[-1], out_channels))
            
        ''' MLP layers for pin prediction '''
        self.mlp_pin = torch.nn.ModuleList()
        self.mlp_norms_pin = torch.nn.ModuleList()
        if self.num_mlp_pin == 0:
            self.mlp_pin.append(Lin(gnn_hidden_channels_list[-1], out_pins))
        else:
            self.mlp_pin.append(Seq(Lin(gnn_hidden_channels_list[-1], mlp_hidden_pin[0]), ReLU()))
            self.mlp_norms_pin.append(LayerNorm(mlp_hidden_pin[0]))
            
            for i in range(self.num_mlp_pin - 1):
                self.mlp_pin.append(Seq(Lin(mlp_hidden_pin[i], mlp_hidden_pin[i + 1]), ReLU()))
                self.mlp_norms_pin.append(LayerNorm(mlp_hidden_pin[i+1]))
            
            self.mlp_pin.append(Lin(mlp_hidden_pin[-1], out_pins))

    def forward(self, data):
        
        # x = torch.cat((data.x[:,:-1], data.y_state), dim = 1)
        x = torch.cat((data.x, data.work_seq[:, 0].unsqueeze(-1)), dim = 1)
        edge_index, edge_attr = data.edge_index, data.edge_attr
        # in_mask = data.in_mask.squeeze(dim=-1).bool()
        
        for i in range(self.num_gnn_layers):
            x = self.convs[i](x, edge_index, edge_attr)
            x = F.relu(x)
            x = self.norms[i](x)
        
        x_global = torch.cat((global_mean_pool(x, data.batch), data.global_attr), dim=1)
        
        ''' MLP for pin prediction '''
        for i in range(self.num_mlp_pin):
            x = self.mlp_pin[i](x)
            x = self.mlp_norms_pin[i](x)
        pin_pred = self.mlp_pin[-1](x)

        ''' MLP for timing prediction '''
        for i in range(self.num_mlp_layers):
            x_global = self.mlp[i](x_global)
            x_global = self.mlp_norms[i](x_global)
        arrival_time = self.mlp[-1](x_global)
        # print(f"Last Layer Embedding: {x}")
        return pin_pred, arrival_time


class joint_model(torch.nn.Module):
    def __init__(self, auto_encoder, downstream_model):
        super(joint_model, self).__init__()
        self.auto_encoder = auto_encoder
        self.downstream_model = downstream_model
        
    def forward(self, data):
        data, loss_s_t, loss_w_t, loss_p_t, recon_loss_t = self.build_data(data)
        pin_pred, arrival_time = self.downstream_model(data)
        return pin_pred, arrival_time, loss_s_t, loss_w_t, loss_p_t, recon_loss_t
        
    def build_data(self, data):
        
        ''' Auto-encoder for workload embedding '''
        z_t, g_t, loss_s_t, loss_w_t, loss_p_t, recon_loss_t, pin_pred_t = self.auto_encoder(data)
        
        ''' Generate pin prediction class '''
        _, pred = pin_pred_t.max(dim=1)
        
        ''' build new data for downstream model '''
        data.x = torch.cat([data.x, pred.unsqueeze(1).float()], dim=1)
        data.global_attr = g_t
        
        return data, loss_s_t, loss_w_t, loss_p_t, recon_loss_t
        
        
