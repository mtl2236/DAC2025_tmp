import torch.nn.functional as F
import torch
from torch_geometric.loader import DataListLoader
from torch_geometric.loader import DataLoader
from torch_geometric.data import Data
from torch_geometric.data import Dataset
from torch_geometric.data import Batch
from torch_geometric.utils import negative_sampling
import random
from sklearn.metrics import f1_score, roc_auc_score

def inference(model, data, device):
    model.eval()
    # data = [data1.to(device) for data1 in data]
    ''' Generate negative edges '''
    data = Batch.from_data_list(data).to(device)
    data.neg_edge_index = negative_sampling(data.edge_index, data.x.size(0))
    
    with torch.no_grad():
        
        ''' Pin target '''
        pin_target = data.y_state.squeeze()
        target = data.y * 1e-2
        
        ''' Auto-encoder for workload embedding '''
        z, g, loss_s, loss_w, loss_p, recon_loss, pin_pred = model.module.auto_encoder(data)
        
        ''' Generate pin prediction class '''
        _, pred = pin_pred.max(dim=1)
        
        ''' build new data for downstream model '''
        data.x = torch.cat([data.x, pred.unsqueeze(1).float()], dim=1)
        data.global_attr = g
        
        ''' Downstream model '''
        out_pin_down, arrival_time = model.module.downstream_model(data)
        
        ''' Downstream model loss '''
        loss_time = F.mse_loss(arrival_time.squeeze(1), target)
        loss_pin = F.cross_entropy(out_pin_down, pin_target)
        
        ''' adj recalculation metric '''
        my_auc, my_ap = model.module.auto_encoder.test(z, data.edge_index, data.neg_edge_index)
        
        ''' Compute pin classification accuracy '''
        correct = pred.eq(pin_target).sum().item()
        total = pin_target.size(0)
        
        acc = correct / total
        
        f1 = f1_score(pin_target.cpu().numpy(), pred.cpu().numpy(), average='weighted')
        
        probs = F.softmax(pin_pred, dim=1).cpu().numpy() 
        pin_target_one_hot = torch.nn.functional.one_hot(pin_target, num_classes=3).cpu().numpy()
        auc = roc_auc_score(pin_target_one_hot, probs, average='macro', multi_class='ovr')
        
    data.to("cpu")
        
    return arrival_time.item(), target.item(), loss_s.item(), loss_w.item(), loss_p.item(), loss_time.item(), loss_pin.item(), my_auc, my_ap, acc, f1, auc