import os
import torch
from torch_geometric.data import Data
from torch_geometric.data import Dataset
import random
import numpy as np
import time
from utility_function import *
from model import *
from torch.optim.lr_scheduler import LinearLR, SequentialLR
from torch_geometric.nn import DataParallel
from torch_geometric.loader import DataListLoader
import datetime
from collections import OrderedDict
from matplotlib import pyplot as plt

def set_seed(seed=42):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    np.random.seed(seed)
    random.seed(seed)

class MyDataset(Dataset):
    def __init__(self, data_list):
        super().__init__()
        self.data_list = data_list

    def len(self):
        return len(self.data_list)

    def get(self, idx):
        return self.data_list[idx]

    def save(self, path):
        torch.save(self.data_list, path)

class Config_downstream:
    def __init__(self):
        self.input_dim = 13 # 14 for 45nm, 13 for 7nm
        self.head = 2
        # self.hidden_GCN = [64, 128, 256, 512] origin
        self.hidden_GCN = [64, 64, 128, 128]
        ''' empty list means 1 MLP layer for final prediction '''
        self.hidden_MLP = [] 
        self.hidden_pin_MLP = []
        self.output_dim = 1 
        self.output_pin_dim = 3
        self.lr = 1e-3
        self.weight_decay = 0
        self.step_size = 150
        self.gamma = 0.5
        self.patience = 200
        self.batch_size = 8
        self.epoch = 200
        self.adam_beta1 = 0.9
        self.adam_beta2 = 0.999
        self.adam_eps = 1e-8
        self.finetune = False
        self.weight_ft = 0.1

class Config_gae:
    def __init__(self):
        self.input_dim = 12 # 13 for 45nm, 12 for 7nm
        self.head = 1
        self.hidden_GCN = [256, 128, 128, 64, 64, 64]
        self.hidden_MLP = [] 
        self.hidden_pin_MLP = [64, 128]
        self.output_dim = 32
        self.wk_dim = 1
        self.pin_dim = 3
        self.loss_weight_list = [1.0, 0.1, 1.0]
        self.lr = 1e-3
        self.weight_decay = 0
        self.step_size = 150
        self.gamma = 0.5
        self.patience = 200
        self.batch_size = None
        self.epoch = 200
        self.adam_beta1 = 0.9
        self.adam_beta2 = 0.999
        self.adam_eps = 1e-8

""" GPU """
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def main():
    
    # torch.autograd.set_detect_anomaly(True)
    flag = "7nm_ft"
    """ hyperparameter """
    config_1 = Config_downstream()
    config_2 = Config_gae()
    
    ''' file name '''
    testing_file = f"./testing_all_7nm_60K.pt"
    model_name_joint = f"./7nm_all_ft_joint.pth"
    save_path_csv = f"./tmp/"
    filename_all = f"unseen_workload_{flag}_all.csv"
    
    """ random seed """
    set_seed(42)
    
    """ load the data """
    dataset = list(torch.load(testing_file)) 
    random.shuffle(dataset)
    unseen_loader = DataListLoader(dataset, batch_size=1, shuffle=True)
    dataset = 0
    
    """ load the model parameter """
    state_dict = torch.load(model_name_joint, map_location=torch.device(device))
    
    """ GAE model building """
    encoder = Encoder(config_2.input_dim, config_2.hidden_GCN, config_2.output_dim)
    decoder = None
    workload_decoder = WorkloadDecoder(config_2.output_dim, config_2.hidden_MLP, config_2.wk_dim)
    pin_decoder = PinDecoder(config_2.output_dim, config_2.hidden_pin_MLP, config_2.pin_dim)
    gae_model = Baseline_GAE(encoder, decoder, workload_decoder, pin_decoder)
    
    """ downstream model building """
    downstream_model = GAT_base(config_1.input_dim, config_1.hidden_GCN, config_1.hidden_MLP, config_1.hidden_pin_MLP, config_1.output_dim, config_1.output_pin_dim, config_1.head)
    
    """ joint model building """
    model = joint_model(gae_model, downstream_model)
    num_params = sum(p.numel() for p in model.parameters())
    model.to(device)
    model = DataParallel(model)
    
    """ load the model """
    model.load_state_dict(state_dict)
    print("Joint model is building!")
    
    all_data = []
    
    for idx, data in enumerate(unseen_loader):
        pred_t, ture_t, loss_s, loss_w, loss_p, loss_time, loss_pin, my_auc, my_ap, acc, f1, auc = inference(model, data, device)
    
        print(idx, [data[0].x.size(0), pred_t, ture_t, loss_s, loss_w, loss_p, loss_time, loss_pin, my_auc, my_ap, acc, f1, auc])
        all_data.append([data[0].x.size(0), pred_t, ture_t, loss_s, loss_w, loss_p, loss_time, loss_pin, my_auc, my_ap, acc, f1, auc])
        
    # save all_data as CSV file
    header_all = 'Circuit, Predicted, True, Loss_S, Loss_W, Loss_P, Loss_Time, Loss_Pin, Adj_AUC, Adj_AP, PIN_Acc, PIN_F1, PIN_AUC'
    np.savetxt(os.path.join(save_path_csv, filename_all), all_data, delimiter=',', header=header_all)

if __name__ == "__main__":
    main()
